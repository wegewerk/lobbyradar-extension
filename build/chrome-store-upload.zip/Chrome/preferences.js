var default_preferences = {'whitelist':"", 'updateinterval':3600};
