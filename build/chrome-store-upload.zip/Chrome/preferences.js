var default_preferences = {'myBool':false, 'myBoolint':1, 'myInteger':2, 'myString':"this is the default string value", 'myMenulist':0, 'myRadio':"a"};
